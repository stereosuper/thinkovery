(function checklist(blocks, editor, element) {
    const el = element.createElement;
    const { RichText } = editor;

    blocks.registerBlockType('stereoberg/question-answer', {
        title: 'Question Answer',
        icon: {
            src: 'list-view',
            foreground: '#1e5e32',
        },
        category: 'custom-layouts',
        attributes: {
            question: {
                type: 'array',
                source: 'children',
                selector: 'h3',
            },
            answer: {
                type: 'array',
                source: 'children',
                selector: 'p',
            },
        },
        edit(props) {
            const { question, answer } = props.attributes;

            function onChangeQuestion(value) {
                props.setAttributes({ question: value });
            }

            function onChangeAnswer(value) {
                props.setAttributes({ answer: value });
            }

            return el(
                'div',
                { className: props.className },
                el(RichText, {
                    tagName: 'h3',
                    className: 'question',
                    inline: true,
                    placeholder: 'Question',
                    value: question,
                    onChange: onChangeQuestion,
                }),
                el(
                    'div',
                    { className: 'answer js-answer' },
                    el(
                        'div',
                        { className: 'answer-content' },
                        el(RichText, {
                            tagName: 'p',
                            placeholder: 'Write answer here...',
                            value: answer,
                            onChange: onChangeAnswer,
                        })
                    )
                )
            );
        },
        save(props) {
            const { question, answer } = props.attributes;
            return el(
                'div',
                { className: props.className },
                el(RichText.Content, {
                    tagName: 'h3',
                    value: question,
                }),
                el(
                    'div',
                    { className: 'answer js-answer', },
                    el(
                        'div',
                        { className: 'answer-content' },
                        el(RichText.Content, {
                            tagName: 'p',
                            value: answer,
                        })
                    )
                )
            );
        },
    });
})(window.wp.blocks, window.wp.editor, window.wp.element);

// '<svg class="icon"><use href="#icon-checkmark"/></svg>',
