(function checklist(blocks, editor, element) {
    const el = element.createElement;
    const { RichText } = editor;

    blocks.registerBlockType('stereoberg/image-gallery-image-right', {
        title: 'Image right',
        icon: {
            src: 'yes',
            foreground: '#1e5e32',
        },
        category: 'custom-layouts',
        attributes: {
            title: {
                type: 'array',
                source: 'children',
                selector: 'h2',
            },
            lines: {
                type: 'array',
                source: 'children',
                selector: '.checklist',
            },
        },
        edit(props) {
            const { lines, title } = props.attributes;

            function onChangeTitle(value) {
                props.setAttributes({ title: value });
            }

            function onChangeLines(value) {
                props.setAttributes({ lines: value });
            }

            return el(
                'div',
                { className: props.className },
                el(RichText, {
                    tagName: 'h2',
                    inline: true,
                    placeholder: 'Ecrire titre',
                    value: title,
                    onChange: onChangeTitle,
                }),
                el(RichText, {
                    tagName: 'ul',
                    multiline: 'li',
                    className: 'checklist',
                    value: lines,
                    onChange: onChangeLines,
                })
            );
        },
        save(props) {
            const { lines, title } = props.attributes;
            return el(
                'div',
                { className: props.className },
                el(RichText.Content, {
                    tagName: 'h2',
                    value: title,
                }),
                el(RichText.Content, {
                    tagName: 'ul',
                    className: 'checklist',
                    value: lines,
                })
            );
        },
    });
})(window.wp.blocks, window.wp.editor, window.wp.element);
