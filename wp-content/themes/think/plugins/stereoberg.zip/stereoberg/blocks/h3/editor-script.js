(function checklist({ blocks, editor, element }) {
    const el = element.createElement;
    const { RichText } = editor;

    // Register block
    blocks.registerBlockType('stereoberg/h3', {
        title: 'H3',
        icon: {
            src: 'book',
            foreground: '#1e5e32',
        },
        category: 'common',
        attributes: {
            title: {
                type: 'array',
                source: 'children',
                selector: 'h3',
            },
        },
        edit(props) {
            const { title } = props.attributes;

            function onChangeTitle(value) {
                props.setAttributes({ title: value });
            }

            return el(RichText, {
                tagName: 'h3',
                className: props.className,
                inline: true,
                placeholder: 'Ecrire titre',
                value: title,
                onChange: onChangeTitle,
            });
        },
        save(props) {
            const { title } = props.attributes;
            return el(RichText.Content, {
                tagName: 'h3',
                className: props.className,
                value: title,
            });
        },
    });
})({
    wp: window.wp,
    blocks: window.wp.blocks,
    editor: window.wp.editor,
    element: window.wp.element,
    withSelect: window.wp.data.withSelect,
    compose: window.wp.compose.compose,
    ifCondition: window.wp.compose.ifCondition,
});
