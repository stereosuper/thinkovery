(function checklist(blocks, editor, element) {
    const el = element.createElement;
    const { RichText, MediaUpload } = editor;

    blocks.registerBlockType('stereoberg/step', {
        title: 'Step',
        icon: {
            src: 'list-view',
            foreground: '#1e5e32',
        },
        category: 'custom-layouts',
        attributes: {
            title: {
                type: 'array',
                source: 'children',
                selector: 'h3',
            },
            text: {
                type: 'array',
                source: 'children',
                selector: 'p',
            },
            image: {
                selector: 'img',
                url: '',
                alt: '',
            },
        },
        edit(props) {
            const { attributes, setAttributes, className } = props;
            const { title, text } = attributes;

            function onChangeTitle(value) {
                setAttributes({ title: value });
            }
            function onChangeText(value) {
                setAttributes({ text: value });
            }

            return el(
                'div',
                { className },
                // el(MediaUpload, {
                //     allowedTypes: ['image'],
                //     value: null,
                //     onSelect: img => {
                //         setAttributes({
                //             image: { url: img.url },
                //         });
                //     },
                // }),
                el(RichText, {
                    tagName: 'h3',
                    className: 'title',
                    inline: true,
                    placeholder: 'Titre',
                    value: title,
                    onChange: onChangeTitle,
                }),
                el(RichText, {
                    tagName: 'p',
                    className: 'text',
                    placeholder: 'Text',
                    value: text,
                    onChange: onChangeText,
                })
            );
        },
        save(props) {
            const { title, text, image } = props.attributes;
            return el(
                'div',
                { className: props.className },
                // el('img', {
                //     src: image.url,
                // }),
                el(RichText.Content, {
                    tagName: 'h3',
                    value: title,
                }),
                el(RichText.Content, {
                    tagName: 'p',
                    value: text,
                })
            );
        },
    });
})(window.wp.blocks, window.wp.editor, window.wp.element);
