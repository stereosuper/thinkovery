(function checklist(blocks, editor, element) {
    const el = element.createElement;
    const { RichText } = editor;

    blocks.registerBlockType('stereoberg/blockquote', {
        title: 'Blockquote',
        icon: {
            src: 'format-quote',
            foreground: '#1e5e32',
        },
        category: 'custom-layouts',
        attributes: {
            quote: {
                type: 'array',
                source: 'children',
                selector: 'p',
            },
            sourceName: {
                type: 'array',
                source: 'children',
                selector: 'span',
            },
            sourcePosition: {
                type: 'array',
                source: 'children',
                selector: 'span',
            },
        },
        edit(props) {
            const { quote, sourceName, sourcePosition } = props.attributes;

            function onChangeText(value) {
                props.setAttributes({ quote: value });
            }
            function onChangeSourceName(value) {
                props.setAttributes({ sourceName: value });
            }
            function onChangeSourcePosition(value) {
                props.setAttributes({ sourcePosition: value });
            }

            return el(
                'div',
                { className: props.className },
                el(
                    'blockquote',
                    { className: 'quote' },
                    el(RichText, {
                        tagName: 'p',
                        placeholder: 'Écrire une citation',
                        value: quote,
                        onChange: onChangeText,
                    })
                ),
                el(
                    'cite',
                    { className: 'source' },
                    el(RichText, {
                        tagName: 'span',
                        placeholder: 'Nom de la source',
                        value: sourceName,
                        onChange: onChangeSourceName,
                    }),
                    el(RichText, {
                        tagName: 'span',
                        placeholder: 'Poste de la source',
                        value: sourcePosition,
                        onChange: onChangeSourcePosition,
                    })
                )
            );
        },
        save(props) {
            const { quote, sourceName, sourcePosition } = props.attributes;
            return el(
                'div',
                { className: props.className },
                el(
                    'blockquote',
                    { className: 'quote' },
                    el(RichText.Content, {
                        tagName: 'p',
                        value: quote,
                    })
                ),
                el(
                    'cite',
                    { className: 'source' },
                    el(RichText.Content, {
                        tagName: 'span',
                        className: 'name',
                        value: sourceName,
                    }),
                    el(RichText.Content, {
                        tagName: 'span',
                        className: 'position',
                        value: sourcePosition,
                    })
                )
            );
        },
    });
})(window.wp.blocks, window.wp.editor, window.wp.element);
