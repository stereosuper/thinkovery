(function (blocks, editor, components, element) {
    var el = element.createElement;
    var registerBlockType = blocks.registerBlockType;
    var RichText = editor.RichText;
    var BlockControls = editor.BlockControls;
    var MediaUpload = editor.MediaUpload;

    registerBlockType('stereoberg/video', {
        title: 'Video',
        description: 'A custom block for displaying video with cover',
        icon: {
            src: 'id',
            foreground: '#1e5e32',
        },
        category: 'custom-layouts',
        attributes: {
            mediaID: {
                type: 'number'
            },
            mediaURL: {
                type: 'string',
                source: 'attribute',
                selector: 'img',
                attribute: 'src'
            },
            video: {
                type: 'text'
            }
        },

        edit: function (props) {
            var attributes = props.attributes;

            var onSelectImage = function (media) {
                    return props.setAttributes({
                        mediaURL: media.url,
                        mediaID: media.id
                });
            };

            return [
                el(BlockControls, {key: 'controls'},
                    el('div', {className: 'components-toolbar'},
                        el(MediaUpload, {
                            onSelect: onSelectImage,
                            type: 'image',
                            render: function (obj) {
                                return el(components.Button, {
                                    className: 'components-icon-button components-toolbar__control',
                                    onClick: obj.open
                                },
                                el('svg', {className: 'dashicon dashicons-edit', width: '20', height: '20'},
                                    el('path', {d: 'M2.25 1h15.5c.69 0 1.25.56 1.25 1.25v15.5c0 .69-.56 1.25-1.25 1.25H2.25C1.56 19 1 18.44 1 17.75V2.25C1 1.56 1.56 1 2.25 1zM17 17V3H3v14h14zM10 6c0-1.1-.9-2-2-2s-2 .9-2 2 .9 2 2 2 2-.9 2-2zm3 5s0-6 3-6v10c0 .55-.45 1-1 1H5c-.55 0-1-.45-1-1V8c2 0 3 4 3 4s1-3 3-3 3 2 3 2z'})
                                ));
                            }
                        })
                    )
                ),
                el('div', {
                    className: props.className,
                    style: { textAlign: attributes.alignment }
                },
                    el('div', {className: 'video-cover'},
                        el(MediaUpload, {
                            onSelect: onSelectImage,
                            type: 'image',
                            value: attributes.mediaID,
                            render: function (obj) {
                                return el(components.Button, {
                                    className: attributes.mediaID ? 'image-button' : 'button button-large',
                                    onClick: obj.open
                                },
                                    !attributes.mediaID ? 'Upload Image' : el('img', {src: attributes.mediaURL})
                                );
                            }
                        })
                    ),
                    el('div', {className: 'video-id'},
                        el(RichText, {
                            key: 'editable',
                            placeholder: 'Video id',
                            keepPlaceholderOnFocus: true,
                            value: attributes.video,
                            onChange: function (text) {
                                props.setAttributes({video: text})
                            }
                        })
                    )
                )
            ];
        },

        save: function (props) {
            var attributes = props.attributes;

            return (
                el('div', {
                    className: 'js-video video',
                    'data-id': attributes.video
                },
                    el('div', {className: 'iframe'}),
                    el('div', {className: 'cover', style: {backgroundImage: 'url(' + attributes.mediaURL + ')'}}),
                    el('div', {className: 'play'}),
                    el('button', {className: 'cross js-cross', type: 'button'},
                        el('span', {className: 'cross-line first-cross-line'}),
                        el('span', {className: 'cross-line second-cross-line'})
                    ),
                    el('div', {className: 'player-background js-cross'})
                )
            );
        }
    });

})(
    window.wp.blocks,
    window.wp.editor,
    window.wp.components,
    window.wp.element
);