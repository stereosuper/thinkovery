<?php 

/**
 * Plugin Name: Stéréoberg
 * Author: Stéréosuper
 * Version: 1.0.7
 */

add_theme_support('align-wide');

// Allow only some core blocks
function allowed_gutenberg_blocks( $allowed_blocks, $post ) {
    $common_blocks = array(
        'core/paragraph',
        'core/image',
        'core/heading',
        'core/gallery',
        'core/list',
        'core/cover',
        'core/video'
    );

    $formatting_blocks = array();

    $layout_blocks = array(
        'core/button',
        'core/columns',
        'core/media-text',
        'core/separator',
        'core/spacer',
    );

    $widget_blocks = array(
        'core/shortcode',
    );

    $embed_blocks = array(
        'core/embed',
        'core-embed/twitter',
        'core-embed/youtube',
        'core-embed/facebook',
        'core-embed/instagram',
        'core-embed/wordpress',
        'core-embed/soundcloud',
        'core-embed/spotify',
        'core-embed/flickr',
        'core-embed/vimeo',
        'core-embed/animoto',
        'core-embed/cloudup',
        'core-embed/collegehumor',
        'core-embed/dailymotion',
        'core-embed/funnyordie',
        'core-embed/hulu',
        'core-embed/imgur',
        'core-embed/issuu',
        'core-embed/kickstarter',
        'core-embed/meetup-com',
        'core-embed/mixcloud',
        'core-embed/photobucket',
        'core-embed/polldaddy',
        'core-embed/reddit',
        'core-embed/reverbnation',
        'core-embed/screencast',
        'core-embed/scribd',
        'core-embed/slideshare',
        'core-embed/smugmug',
        'core-embed/speaker',
        'core-embed/ted',
        'core-embed/tumblr',
        'core-embed/videopress',
        'core-embed/wordpress-tv',
    );

    $stereo_blocks = array(
        'stereoberg/checklist',
        'stereoberg/h2',
        'stereoberg/h3',
        'stereoberg/h4',
        'stereoberg/question-answer',
        'stereoberg/blockquote',
        'stereoberg/video',
    );

    $allowed_blocks = array_merge($common_blocks, $formatting_blocks, $layout_blocks, $widget_blocks, $embed_blocks, $stereo_blocks);
    
	// if( $post->post_type === 'page' ) {
    //     $allowed_blocks[] = 'core/shortcode';
	// }
	return $allowed_blocks;
}
add_filter( 'allowed_block_types', 'allowed_gutenberg_blocks', 10, 2 );

// Register Gutenberg custom blocks
function register_gutenberg_blocks() {

    // Create checklist block
    wp_register_script(
        'stereoberg-checklist',
        plugins_url('/blocks/checklist/editor-script.js', __FILE__),
        array('wp-blocks', 'wp-element', 'wp-editor'),
        filemtime( plugin_dir_path( __FILE__ ) . 'blocks/checklist/editor-script.js' )
    );
    
    wp_register_style(
        'stereoberg-checklist-editor',
        plugins_url( '/blocks/checklist/editor-style.css', __FILE__ ),
        array( 'wp-edit-blocks' ),
        filemtime( plugin_dir_path( __FILE__ ) . 'blocks/checklist/editor-style.css' )
    );
    
    register_block_type( 'stereoberg/checklist', array(
        'editor_style' => 'stereoberg-checklist-editor',
        'editor_script' => 'stereoberg-checklist',
    ) );

    // Create h2 block
    wp_register_script(
        'stereoberg-h2',
        plugins_url('/blocks/h2/editor-script.js', __FILE__),
        array('wp-blocks', 'wp-element', 'wp-editor'),
        filemtime( plugin_dir_path( __FILE__ ) . 'blocks/h2/editor-script.js' )
    );
    
    wp_register_style(
        'stereoberg-h2-editor',
        plugins_url( '/blocks/h2/editor-style.css', __FILE__ ),
        array( 'wp-edit-blocks' ),
        filemtime( plugin_dir_path( __FILE__ ) . 'blocks/h2/editor-style.css' )
    );
    
    register_block_type( 'stereoberg/h2', array(
        'editor_style' => 'stereoberg-h2-editor',
        'editor_script' => 'stereoberg-h2',
    ) );

    // Create h3 block
    wp_register_script(
        'stereoberg-h3',
        plugins_url('/blocks/h3/editor-script.js', __FILE__),
        array('wp-blocks', 'wp-element', 'wp-editor'),
        filemtime( plugin_dir_path( __FILE__ ) . 'blocks/h3/editor-script.js' )
    );
    
    wp_register_style(
        'stereoberg-h3-editor',
        plugins_url( '/blocks/h3/editor-style.css', __FILE__ ),
        array( 'wp-edit-blocks' ),
        filemtime( plugin_dir_path( __FILE__ ) . 'blocks/h3/editor-style.css' )
    );
    
    register_block_type( 'stereoberg/h3', array(
        'editor_style' => 'stereoberg-h3-editor',
        'editor_script' => 'stereoberg-h3',
    ) );

    // Create h4 block
    wp_register_script(
        'stereoberg-h4',
        plugins_url('/blocks/h4/editor-script.js', __FILE__),
        array('wp-blocks', 'wp-element', 'wp-editor'),
        filemtime( plugin_dir_path( __FILE__ ) . 'blocks/h4/editor-script.js' )
    );
    
    wp_register_style(
        'stereoberg-h4-editor',
        plugins_url( '/blocks/h4/editor-style.css', __FILE__ ),
        array( 'wp-edit-blocks' ),
        filemtime( plugin_dir_path( __FILE__ ) . 'blocks/h4/editor-style.css' )
    );
    
    register_block_type( 'stereoberg/h4', array(
        'editor_style' => 'stereoberg-h4-editor',
        'editor_script' => 'stereoberg-h4',
    ) );

    // Create questions / answers
    wp_register_script(
        'stereoberg-question-answer',
        plugins_url('/blocks/question-answer/editor-script.js', __FILE__),
        array('wp-blocks', 'wp-element', 'wp-editor'),
        filemtime( plugin_dir_path( __FILE__ ) . 'blocks/question-answer/editor-script.js' )
    );
    
    wp_register_style(
        'stereoberg-question-answer-editor',
        plugins_url( '/blocks/question-answer/editor-style.css', __FILE__ ),
        array( 'wp-edit-blocks' ),
        filemtime( plugin_dir_path( __FILE__ ) . 'blocks/question-answer/editor-style.css' )
    );
    
    register_block_type( 'stereoberg/question-answer', array(
        'editor_style' => 'stereoberg-question-answer-editor',
        'editor_script' => 'stereoberg-question-answer',
    ) );

    // Create blockquote block
    wp_register_script(
        'stereoberg-blockquote',
        plugins_url('/blocks/blockquote/editor-script.js', __FILE__),
        array('wp-blocks', 'wp-element', 'wp-editor'),
        filemtime( plugin_dir_path( __FILE__ ) . 'blocks/blockquote/editor-script.js' )
    );
    
    wp_register_style(
        'stereoberg-blockquote-editor',
        plugins_url( '/blocks/blockquote/editor-style.css', __FILE__ ),
        array( 'wp-edit-blocks' ),
        filemtime( plugin_dir_path( __FILE__ ) . 'blocks/blockquote/editor-style.css' )
    );
    
    register_block_type( 'stereoberg/blockquote', array(
        'editor_style' => 'stereoberg-blockquote-editor',
        'editor_script' => 'stereoberg-blockquote',
    ) );

    // Create video block
    wp_register_script(
        'stereoberg-video',
        plugins_url('/blocks/video/editor-script.js', __FILE__),
        array( 'wp-blocks', 'wp-components', 'wp-element', 'wp-editor' ),
        filemtime( plugin_dir_path( __FILE__ ) . 'blocks/video/editor-script.js' )
    );
    
    wp_register_style(
        'stereoberg-video-editor',
        plugins_url( '/blocks/video/editor-style.css', __FILE__ ),
        array( 'wp-edit-blocks' ),
        filemtime( plugin_dir_path( __FILE__ ) . 'blocks/video/editor-style.css' )
    );
    
    register_block_type( 'stereoberg/video', array(
        'editor_style' => 'stereoberg-video-editor',
        'editor_script' => 'stereoberg-video',
    ) );

    // Register formats
    wp_register_script(
        'stereoberg-format-change-color',
        plugins_url( '/formats/change-color/editor-format.js', __FILE__ ),
        array( 'wp-rich-text' )
    );
}
// TODO: check admin init for admin styles
add_action( 'init', 'register_gutenberg_blocks' );

function my_custom_format_enqueue_assets_editor() {
    wp_enqueue_script( 'stereoberg-format-change-color' );
}
add_action( 'enqueue_block_editor_assets', 'my_custom_format_enqueue_assets_editor' );

// NOTE: Not shown if no blocks registered under the new categories
function stereoberg_block_categories( $categories, $post ) {
    if ( $post->post_type !== 'reference' ) {
        return $categories;
    }
    $updated_categories = array_merge(
        $categories,
        array(
            array(
                'slug' => 'custom-layouts',
                'title' => __( 'Custom layouts', 'stereoberg' ),
                'icon'  => NULL,
            )
        )
    );

    return $updated_categories;
}
add_filter( 'block_categories', 'stereoberg_block_categories', 10, 2 );

?>