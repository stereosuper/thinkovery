(function checklist({ wp, editor, element, withSelect, compose, ifCondition }) {
    const el = element.createElement;

    // Register format
    const ColorButton = props =>
        el(editor.RichTextToolbarButton, {
            icon: 'editor-code',
            title: 'Change selection color',
            onClick() {
                props.onChange(
                    wp.richText.toggleFormat(props.value, {
                        type: 'stereoberg-format/change-color',
                    })
                );
            },
            isActive: props.isActive,
        });
    const ConditionalButton = compose(
        withSelect(select => ({
            selectedBlock: select('core/editor').getSelectedBlock(),
        })),
        ifCondition(
            props =>
                props.selectedBlock &&
                (props.selectedBlock.name === 'stereoberg/h2' ||
                    props.selectedBlock.name === 'stereoberg/h3' ||
                    props.selectedBlock.name === 'stereoberg/h4')
        )
    )(ColorButton);

    wp.richText.registerFormatType('stereoberg-format/change-color', {
        title: 'Sample output',
        tagName: 'span',
        className: 'color',
        edit: ConditionalButton,
    });
})({
    wp: window.wp,
    blocks: window.wp.blocks,
    editor: window.wp.editor,
    element: window.wp.element,
    withSelect: window.wp.data.withSelect,
    compose: window.wp.compose.compose,
    ifCondition: window.wp.compose.ifCondition,
});
